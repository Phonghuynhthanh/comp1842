const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const express = require('express'),
    app = express(),
    port = process.env.PORT || 3000,
    Task = require('./api/models/todoListModel');

// mongoose instance connection url connection
mongoose.Promise = global.Promise;
mongoose.connect('mongodb+srv://phonghtgcs220450:Phong2701%40@fgwweb2.exskqve.mongodb.net/?retryWrites=true&w=majority&appName=FGWWeb2');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const routes = require('./api/routes/todoListRoutes');
routes(app);

app.listen(port);

console.log('todo list RESTful API server started on:' + port);
