// Task 9
app.component('ProductDisplay', {
    props: {
        premium:{
            type: Boolean,
            required: true
        },
// Challenge Task8
        details:{
            type: Array,
            require: true
        }
    },
  template: 
  /*html*/
    `<div class="product-container">
      <div class="product-image">
        <img 
          v-bind:src="image"
          :class="{ 'out-of-stock-img': !inStock }"
        >
      </div>
      <div>
        <h1>{{ title }}</h1>
        <p v-if="saleMessage">{{ saleMessage }}</p>
        <a v-bind:href="url" target="_blank">Visit Product Page</a>
        <p v-if="inStock > 10">In Stock</p>
        <p v-else-if="inStock > 0">Almost sold out!</p>
        <p v-else>Out of Stock</p>

        <p>Shipping: {{ shipping() }}</p>

        <p>Desciption: Green</p>
        <product-details :details="details"></product-details>        
        <ul>
          <li v-for="size in sizes" :key="size">{{ size }}</li>
        </ul>
        <ul>
          <li v-for="detail in details" :key="detail">{{ detail }}</li>
        </ul>

        <div 
          v-for="(variant, index) in variants"
          :key="variant.id"
          @mouseover="updateVariant(index)"
          class="color-circle"
          :class="{ active: selectedVariant === index }"
          :style="{ backgroundColor: variant.color }"
        ></div>
        <button 
          class="button"
          :class="{ disabledButton: !inStock }"
          :disabled="!inStock"
          v-on:click="addToCart"
        >Add to Cart</button>
        <br>
        <button 
          class="button"
          v-on:click="removeFromCart"
        >Remove from Cart</button>
      </div>
    </div>
  `,
  data() {
    return {
      product: "Socks",
      brand: "Phong's Shop",
      url: "https://www.phongshop.com/products/socks",
      selectedVariant: 0,
      onSale: true,
      details: [
        "50% cotton",
        "30% wool",
        "20% polyester"
      ],
      variants: [
        {
          id: 2234,
          color: "green",
          image: "./assets/images/socks_green.jpg",
          quantity: 12
        },
        {
          id: 2235,
          color: "blue",
          image: "./assets/images/socks_blue.jpg",
          quantity: 0
        }
      ]
    }
  },
  computed: {
    title() {
      return this.brand + " " + this.product;
    },
    image() {
      return this.variants[this.selectedVariant].image;
    },
    inStock() {
      return this.variants[this.selectedVariant].quantity;
    },
    saleMessage() {
      if (this.onSale && this.inStock > 0) {
        return this.brand + " " + this.product + " is on sale!";
      }
      return "";
    }
  },
  methods: {
    // Task 10
    addToCart() {
        this.$emit('add-to-cart', this.variants[this.selectedVariant].id)
    },
    // Challenge Task 10
    removeFromCart() {
        this.$emit('remove-from-cart', this.variants[this.selectedVariant].id)
    },
    updateVariant(index) {
      this.selectedVariant = index;
    },
    shipping() {
    if (this.premium) {
      return 'Free'
    }
      return 2.99
    }
  }
})