// Task 9
const app = Vue.createApp({
    data() {
    return {
        cart: [],
        premium: false
        }
    },
    // Task 10
    methods:{
        updateCart(id) {
            this.cart.push(id);
    },
    // Challenge Task 10
        removeFromCart(id) {
            const index = this.cart.indexOf(id);
            if (index > -1) {
                this.cart.splice(index, 1);
            }
    }
}})