<template>
  <div>
    <h2>Vocabulary Quiz</h2>
    <div v-if="words.length && current < words.length">
      <div class="ui segment">
        <strong>What is the Vietnamese meaning of:</strong>
        <h3>{{ words[current].english }}</h3>
        <div class="ui buttons">
          <button
            v-for="(choice, idx) in choices"
            :key="idx"
            class="ui button"
            :class="{ positive: selected === idx && correct, negative: selected === idx && !correct }"
            @click="checkAnswer(idx)"
            :disabled="selected !== null"
          >
            {{ choice }}
          </button>
        </div>
        <div v-if="selected !== null" style="margin-top: 10px;">
          <span v-if="correct" style="color: green;">Correct!</span>
          <span v-else style="color: red;">Wrong! Correct answer: {{ words[current].vietnamese }}</span>
          <button class="ui button" @click="nextQuestion">Next</button>
        </div>
      </div>
    </div>
    <div v-else>
      <h3>Quiz Finished!</h3>
      <p>Your score: {{ score }}/{{ words.length }}</p>
      <button class="ui button" @click="restart">Restart</button>
    </div>
  </div>
</template>

<script>
import { api } from '../helpers/helpers';

export default {
  name: 'VocabTest',
  data() {
    return {
      words: [],
      current: 0,
      choices: [],
      selected: null,
      correct: false,
      score: 0
    };
  },
  async mounted() {
    this.words = await api.getWords();
    this.shuffleWords();
    this.setChoices();
  },
  methods: {
    shuffleWords() {
      // Shuffle words array
      this.words = this.words.sort(() => Math.random() - 0.5);
    },
    setChoices() {
      if (!this.words.length || this.current >= this.words.length) return;
      const correct = this.words[this.current].vietnamese;
      // Lấy 3 đáp án sai ngẫu nhiên
      let wrongs = this.words
        .filter((w, idx) => idx !== this.current)
        .map(w => w.vietnamese);
      wrongs = this.shuffleArray(wrongs).slice(0, 3);
      this.choices = this.shuffleArray([correct, ...wrongs]);
      this.selected = null;
      this.correct = false;
    },
    shuffleArray(arr) {
      return arr.slice().sort(() => Math.random() - 0.5);
    },
    checkAnswer(idx) {
      this.selected = idx;
      if (this.choices[idx] === this.words[this.current].vietnamese) {
        this.correct = true;
        this.score++;
      } else {
        this.correct = false;
      }
    },
    nextQuestion() {
      this.current++;
      this.setChoices();
    },
    restart() {
      this.current = 0;
      this.score = 0;
      this.shuffleWords();
      this.setChoices();
    }
  }
};
</script>