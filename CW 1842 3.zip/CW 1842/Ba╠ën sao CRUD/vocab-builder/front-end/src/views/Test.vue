<template>
  <div>
    <h2>Test Your Knowledge</h2>
    <VocabTest />
  </div>
</template>

<script>
import VocabTest from '../components/VocabTest.vue';

export default {
  name: "Test",
  components: {
    VocabTest
  }
}
</script>